﻿using core.services.Registration;
using Dapper;
using Domain;
using Domain.Dto;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using System.Data;

namespace rolebased.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class UserController : ControllerBase
    {
        private readonly UserService _userService;
        private readonly IConfiguration _configuration;
        private readonly SqlConnection _connection;
        public UserController(UserService userService,IConfiguration configuration)
        {
            _userService = userService;
            _configuration = configuration;
            _connection = new SqlConnection(configuration.GetConnectionString("defaultConnection"));
        }
        [Authorize(Roles = "Admin")]
        [HttpGet("All")]
        public async Task<IActionResult> getAll()
        {
            var result = await _connection.QueryAsync<userRegistration>("getAllUser", commandType: CommandType.StoredProcedure);
            if (result == null)
            {
                return NotFound("unavailable");
            }
            return Ok(result);
        }

        [HttpGet("byId")]
        public async Task<IActionResult> getById(Guid id)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@ID", id);

            var result = await _connection.QueryAsync<userRegistration>("getUserById", parameters, commandType: CommandType.StoredProcedure);
            if (result == null)
            {
                return NotFound("unavailable");
            }

         

            return Ok(result);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut]
        public async Task <IActionResult> updateUser(Guid id,registrationDto dto)
        {
            var result = await _userService.UpdateUser(id, dto);
            if (result == null)
            {
                return Ok("notFound");
            }
            return Ok(result);
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete]
        public async Task <IActionResult> deleteUser(Guid id)
        {
            var result = await _userService.DeleteUser(id);
            if(result == null)
            {
                return NotFound("unavailable");
            }
            return Ok(result);
        }
    }
}
