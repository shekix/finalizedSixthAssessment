﻿using core;
using core.services.Registration;
using Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Reflection;

namespace rolebased.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorizationController : ControllerBase
    {
        private readonly IConfiguration _config;
        private readonly registrationService _registrationService;
        public AuthorizationController( IConfiguration config,registrationService registrationService)
        {
            _registrationService = registrationService;
            _config = config;
        }

        [HttpPost("register")]
        public async Task<IActionResult> registerUser(userRegistration user)
        {
            var result = await _registrationService.userRegistration(user);
            if (result == null) { 
            return Ok("userAlreadyExists");
            }
            return Ok("RegistrationSuccessful");
        }



        [HttpPost("Userlogin")]
        public async Task<IActionResult> loginUser(Login user)
        {
            var result = await _registrationService.UserLogin(user);
            if (result == null)
            {
                return Ok("unsuccessful");
            }
            if(result == "inactive")
            {
                return Ok("inactive");
            }
  
            return Ok(result);
        }


    }
}
