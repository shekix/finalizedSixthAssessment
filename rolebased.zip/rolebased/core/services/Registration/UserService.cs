﻿using core.Interface;
using Domain;
using Domain.Dto;
using Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.services.Registration
{
    public class UserService : IUser
    {
        private readonly AppDbContext _context;

        public UserService(AppDbContext context)
        {
            _context = context;
        }

        //implemented using dapper in controller
        //public async Task<IEnumerable<userRegistration>> GetAllUsers()
        //{
            
        //    var users = await _context.userRegistrations.ToListAsync();
            
        //    return users;
        //}

        //public async Task<userRegistration> GetUserById(Guid id)
        //{
        //    var user = await _context.userRegistrations.FindAsync(id);
        //    return user;
        //}

        public async Task<userRegistration> UpdateUser(Guid id, registrationDto userdto)
        {
            var user = await _context.userRegistrations.FindAsync(id);
            if (user != null)
            {
                user.FirstName = userdto.FirstName;
                user.LastName = userdto.LastName;
                user.Role = userdto.Role;
                user.Gender = userdto.Gender;
                user.Dob = userdto.Dob;
                await _context.SaveChangesAsync();
                return user;
            }
            return null;
            

        }

        public async Task<userRegistration> DeleteUser(Guid id)
        {
            var user = await _context.userRegistrations.FindAsync(id);
            if (user != null) { 
                user.isActive = false;
                await _context.SaveChangesAsync();
                return user;
            }
            return null;
        }
    }
}
